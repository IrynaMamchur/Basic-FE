
//Task 1.1
let arr = ['Привет,', 'мир', '!']
console.log(arr[0], arr[1], arr[2])

//Task 1.2
let arr1 = ['Привет,', 'мир', '!']
let text = `${arr1[0]} ${arr1[1]} ${arr1[2]}`
console.log(text)

//Task2
let arr2 = ['Привет,', 'мир', '!']
arr2.shift()
arr2.unshift('Пока')
console.log(arr2)

//Task Object 1
let obj = {a: 1, b: 2, c: 3}
console.log(obj.c)
console.log(obj['c'])


//Task Object 2
let weekObj = {'1': 'понедельник', '2':'вторник',  '3':'среда', '4':'четверг', '5':'пятница', '6':'суббота', '7':'воскресенье'}
console.log(weekObj[7])


// Task Цикл 1
let array = [1,2,3,4,5]
for (let i = 0; i < array.length; i++) {
    console.log(array[i]);    
}


//Task Цикл 2

let newArray = [2,5,9,15,0,4]
 for (let i =0; i < newArray.length; i++) {
     if (newArray[i]>3 && newArray[i]<10){
        console.log(newArray[i]);
     }
    }

