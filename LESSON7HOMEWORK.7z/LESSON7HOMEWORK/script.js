
//Task1
let age = prompt('Возраст');
alert(`Вам ${age} лет!`);

let minutesInYear = 525600;
let ageInMinutes = minutesInYear * age;
console.log ("Вам полных " + ageInMinutes + " минут");


//Task2
let number = prompt('число');
alert(`Ваше число ${number}`);

let numberSquare = number * number;
console.log ("Квадрат " + number + " равен " + numberSquare);

//Task3

let number1 = prompt('первое число');
alert(`Ваше первое число ${number1}`);
let number2 = prompt('второе число');
alert(`Ваше второе число ${number2}`);
let sum = Number(number1) + Number(number2);
console.log ("Сумма двух чисел " + number1 +" и "+ number2 +" равна " + sum);


