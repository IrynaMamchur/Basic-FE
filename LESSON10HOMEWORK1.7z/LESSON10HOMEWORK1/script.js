function two(){
let p = document.querySelector ('.nikolas')    
p.innerText = 'Поздравляю!!'
}



function one(){
    let yyy = document.querySelectorAll('p.yyy')
     for (let i = 0; i<=yyy.length; i++){
          yyy[i].innerText = i+1
        }
    }

    function christmas(){
        let p = document.querySelector('.chr')
    p.innerText = 'УУУРРРРААААА!!!!!'
    p.style.color = 'red'
    }