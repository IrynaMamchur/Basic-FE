function two(){
let p = document.querySelector ('.nikolas')    
p.innerText = 'Поздравляю!!'
}

function christmas(){
    let p = document.querySelector('.chr')
p.innerText = 'УУУРРРРААААА!!!!!'
}

function one(){
    let p = document.querySelectorAll('p')
     for (let i = 1; i<=2; i++){
          p[i].style.color = 'red'
        }
    }