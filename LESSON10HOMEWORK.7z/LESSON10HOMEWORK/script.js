
function one(){
let p = document.querySelectorAll('p')
for (let i = 0; i<=1; i++){
     p[i].style.color = 'red'
    }
}




    